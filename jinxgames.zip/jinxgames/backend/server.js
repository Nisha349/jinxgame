// import express from 'express';
// import cors from 'cors';
// import fs from 'fs';
// import bodyParser from 'body-parser';

// const app = express();
// const PORT = 5000;

// app.use(cors());
// app.use(bodyParser.json());

// const SCORE_FILE = './memory-scores.json';

// app.get('/memory-scores', (req, res) => {
//   const data = fs.readFileSync(SCORE_FILE);
//   res.json(JSON.parse(data));
// });

// app.post('/memory-scores', (req, res) => {
//   const { score } = req.body;
//   const data = fs.readFileSync(SCORE_FILE);
//   const scores = JSON.parse(data);
//   scores.push({ score, timestamp: new Date().toISOString() });
//   fs.writeFileSync(SCORE_FILE, JSON.stringify(scores, null, 2));
//   res.status(201).json({ message: 'Score saved' });
// });

// app.listen(PORT, () => {
//   console.log(`Memory Game backend running on http://localhost:${PORT}`);
// });
